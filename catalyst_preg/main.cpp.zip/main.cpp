#include <iostream>
#include <iomanip>
#include <cmath>
#define PI 3.14159265
using namespace std;

struct Point {
    double x,y;
};

double degToRad(double deg) {
    return deg*PI/180.0;
}

double radToDeg(double rad) {
    return 180*rad/PI;
}

class MarsRover {
public:
    double maxSteeringAngle,wheelBase,distance;
    bool degNeg;

    void setSteeringAngle(double angle) {
       degNeg=angle<0;
        maxSteeringAngle=fabs(angle)*PI/180.0;
    }

    double getSteeringAngle() {
        return 180.0*maxSteeringAngle/PI;
    }

    double getTurnRadius() {
        return wheelBase/sin(maxSteeringAngle);
    }

    double getDirection() {
        double alpha = distance/(getTurnRadius());
        for(;alpha>=2.0*PI;alpha-=2*PI);
        for(;alpha<0;alpha+=2*PI);
        if(degNeg) {
            alpha=2*PI-alpha;
        }
        return alpha;
    }

    double returnDirection() {
        return radToDeg(getDirection());
    }

    Point getPosition() {
        Point ret;
        if(maxSteeringAngle==0) {
            ret.x=0;
            ret.y=distance;
        }
        else {
            ret.x=-cos(getDirection())*getTurnRadius()+getTurnRadius();
            ret.y=sin(getDirection())*getTurnRadius();
            if(degNeg) {
                ret.x=-ret.x;
                ret.y=-ret.y;
            }
        }
        return ret;
    }

};

int main()
{
    double wb,dst,sa;
    cin>>wb>>dst>>sa;
    MarsRover r;
    r.distance=dst;
    r.wheelBase=wb;
    r.setSteeringAngle(sa);

    //cout<<r.getTurnRadius()<<' ';
    Point rez=r.getPosition();
    cout<<fixed<<setprecision(2)<<rez.x<<' '<<rez.y<<' '<<r.returnDirection();
    return 0;
}
