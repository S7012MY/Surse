/* Vlad Tudose */
#include <cstdio>
#include <cstring>

#define Lmax 128
#define Rmax 128

int R, M;
int rez;
char X[Rmax], Y[Rmax][3];
char cuv[Lmax];

void back(char *S, int lvl)
{
     char SS[Lmax];
     
     if (lvl > 25 || rez == 1) return;
     
     int L = strlen(S);
     if (L == 1)
     {
        if (S[0] == 'S') rez = 1;
           else if (S[0] <= 'Z' && rez != 1) rez = 2;
        return;
     }
     
     for (int i=0; i<L; ++i)
         for (int j=0; j<R; ++j)
         {
             int Lk = strlen(Y[j]);
             int k;
             for (k=0; k<Lk; ++k)
                 if (S[i+k] != Y[j][k]) break;
             if (k < Lk) continue;
             
             memcpy(SS, S, i+1);
             SS[i] = X[j];
             memcpy(SS+i+1, S+i+Lk, L-i-Lk+1);
             SS[L-Lk+1] = 0;
             
             back(SS, lvl+1);
         }
}

int main()
{
    freopen("minerale.in","r",stdin);
    freopen("minerale.out","w",stdout);
    
    scanf("%d %d\n", &R, &M);
    for (int i=0; i<R; ++i)
        scanf("%c %s\n", &X[i], &Y[i]);
        
    for (int i=0; i<M; ++i)
    {
        scanf("%s\n", &cuv);
        rez = 0;
        back(cuv, 0);
        printf("%d\n", rez);
    }
        
    
    return 0;
}
