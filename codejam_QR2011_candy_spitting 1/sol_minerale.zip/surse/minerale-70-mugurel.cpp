/* Mugurel Andreica */

#include <stdio.h>
#include <vector>
#include <set>

using namespace std;

#define NMAX 30
#define PMAX 401
#define LMAX 105

vector<char> NT[256], okNT[LMAX][LMAX], prod[NMAX][NMAX];
set<char> s;
char pleft[PMAX][10], pright[PMAX][10], sir[LMAX];
int i, j, k, R, M, L, len, oki, okj, okk;
char A, B, C;

int main() {
	freopen("minerale.in", "r", stdin);
	freopen("minerale.out", "w", stdout);
	scanf("%d %d", &R, &M);

	for (i = 1; i <= R; i++) {
		scanf("%s %s", pleft[i], pright[i]);
		L = strlen(pright[i]);
		if (L == 1)
			NT[pright[i][0]].push_back(pleft[i][0] - 'A');
		else
			prod[pright[i][0] - 'A'][pright[i][1] - 'A'].push_back(pleft[i][0] - 'A');
		//fprintf(stderr, "%s->%s\n", pleft[i], pright[i]);
	}
	
	while (M--) {
		scanf("%s", sir + 1);
		L = strlen(sir + 1);
		//fprintf(stderr, "sir=%s\n", sir + 1);
		
		for (i = 1; i <= L; i++) {
			okNT[i][i].clear();
			for (j = 0; j < NT[sir[i]].size(); j++) {
				okNT[i][i].push_back(NT[sir[i]][j]);
			}

			/*
			fprintf(stderr, "(%d,%d):", i, i);
			for (k = 0; k < okNT[i][i].size(); ++k)
				fprintf(stderr, " %d", okNT[i][i][k]);
			fprintf(stderr, "\n");
			*/
		}

		for (len = 2; len <= L; len++)
			for (i = 1; i <= L - len + 1; i++) {
				j = i + len - 1;
				okNT[i][j].clear();
				s.clear();
				
				for (k = i; k < j; k++) {
					for (oki = 0; oki < okNT[i][k].size(); oki++) {
						A = okNT[i][k][oki];
						for (okj = 0; okj < okNT[k + 1][j].size(); okj++) {
							B = okNT[k + 1][j][okj];
							//fprintf(stderr, "(%d,%d): %d %d\n", i, j, A, B);
							for (okk = 0; okk < prod[A][B].size(); okk++) {
								C = prod[A][B][okk];
								//fprintf(stderr, "(%d,%d): %d -> %d %d\n", i, j, C, A, B);

								if (s.find(C) == s.end()) {
									okNT[i][j].push_back(C);
									s.insert(C);
								}
							}
						}
					}
				}

				/*
				fprintf(stderr, "### (%d,%d):", i, j);
				for (k = 0; k < okNT[i][j].size(); ++k)
					fprintf(stderr, " %d", okNT[i][j][k]);
				fprintf(stderr, "\n");
				*/
			}

		if (okNT[1][L].size() == 0) {
			printf("0\n");
		} else {
			for (i = 0; i < okNT[1][L].size(); i++) {
				if (okNT[1][L][i] == ('S' - 'A'))
					break;
			}
				
			if (i < okNT[1][L].size())
				printf("1\n");
			else
				printf("2\n");
		}		
	}
	
	return 0;
}
