/* Adrian Panaete */

#include<cstdio>
#include<cstring>
using namespace std;
int r,t,S,A[30],B[30][30],LG,L,Sol[110][110],ST,DR,MI,SOL(int,int);
char X[4],Y[4],T[110];
int main()
{
	freopen("minerale.in","r",stdin);
	freopen("minerale.out","w",stdout);
	scanf("%d%d",&r,&t);
	S=1<<('S'-'A');
	for(;r;r--)
	{
		scanf("%s%s",X,Y);
		if(Y[0]>='a')A[Y[0]-'a']|=(1<<(X[0]-'A'));
		else B[Y[0]-'A'][Y[1]-'A']|=(1<<(X[0]-'A'));
	}
	for(;t;t--)
	{
		scanf("%s",T+1);
		LG=strlen(T+1);
		for(L=1;L<=LG;L++)Sol[L][L]=A[T[L]-'a'];
		for(L=2;L<=LG;L++)
			for(ST=1,DR=L;DR<=LG;ST++,DR++)
			{
				Sol[ST][DR]=0;
				for(MI=ST;MI<DR;MI++)
					Sol[ST][DR]|=SOL(Sol[ST][MI],Sol[MI+1][DR]);
			}
		if(Sol[1][LG]&S)printf("1\n");
		else
		if(Sol[1][LG])printf("2\n");
		else printf("0\n");
	}
	return 0;
}
int SOL(int U,int V)
{
	int ret=0,nu=0,nv=0,I,J,MU[26],MV[26];
	for(I=0,J=1;U;I++,J<<=1)if(J&U){MU[++nu]=I;U-=J;}
	for(I=0,J=1;V;I++,J<<=1)if(J&V){MV[++nv]=I;V-=J;}
	for(I=1;I<=nu;I++)
		for(J=1;J<=nv;J++)
			ret|=B[MU[I]][MV[J]];
	return ret;
}


