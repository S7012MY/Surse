#include <cstdio>
#include <cstdlib>
#include <cstring>
#define DN 9999999999
#define DM 999999999
using namespace std;

#define FIN  "cri.in"
#define FOUT "vase.out"
#define FOK  "vase.ok"

void error(char msg[], int p)
{
	fprintf(stderr, msg);
	printf("%d", p);
	exit(0);
}

int main(void)
{
    int nr,v1,v2;
    char c1,c2;
    FILE *f;

    f = fopen(FOK, "r");
    if (!f) error("Nu am putut deschide fisierul de verificare", 0);
    if (fscanf(f, "%d %d %c %d %c", &nr,&v1,&c1,&v2,&c2) != 5)
        error("Eroare in fisierul de verificare", 0);

	int snr,sv1,sv2;
	char sc1,sc2;
    f = fopen(FOUT, "r");
    if (!f) error("Fisier de iesire inexistent", 0);
    if (fscanf(f, "%d", &snr) != 1)
        error("Fisier de iesire gol", 0);
    if (nr != snr)
        error("Raspuns gresit", 0);
    else {
		if(fscanf(f, "%d %c %d %c",&sv1,&sc1,&sv2,&sc2)!= 4 || sv1!=v1 || sv2!=v2 || sc1!=c1 || sc2!=c2) error("Primul numar corect",1);
	}
    error("OK", 5);

    return 0;
}

